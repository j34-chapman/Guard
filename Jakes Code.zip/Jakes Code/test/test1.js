const assert = require ('assert');
const { response } = require('express');
process.env.NODE_ENV!= "test";
const main = require('../main-1')



describe ("test suite",function(){
    var status ;
    
    before(function () {
        mockResponse = {
            status (statusCode) {status = statusCode},
            send(error) {}


    };
});


    it("Should use the ejs view engine", function(){
        assert.equal(main.app.get("view engine"),"ejs");


    });


    it ("should report eroor status 500",function(){
        status = 200;
        mockResponse = {
            status:function(statusCode){status = statusCode ;},
            send(error){}
        };
        main.serverError("ERROR",mockResponse);
        assert.equal(status,500);


    });


    it ("should connect to the database",function(done){
        main.connection.ping(function(err){
            assert.equal(err,null);
            done();

        }); 


    });

    after(function(done){ // ending connection to database
        main.connection.end(function() {done();} );
        
    });


});


