var express = require('express');
var mysql = require('mysql');

//load configuration data 
var conf = require('./conf.json');


process.env.NODE_ENV = process.env.NODE_ENV || 'development';
const PORT = conf[process.env.NODE_ENV].port;

var QUERY = 'SELECT * FROM `crime`';
TYPE_QUERY = 'SELECT * FROM `crime` WHERE type = ?';// search query 
const SEARCH_QUERY = 'SELECT * FROM `crime` WHERE `Ward Name` LIKE ?'; //ward name query
var FSA_QUERY = 'SELECT * FROM `crime` order by `All Crimes (number)`  ';

var connection = mysql.createConnection(conf[process.env.NODE_ENV].database);

   
/* var connection = mysql.createConnection({
    "host"     : "localhost", //p mysql5.cems.uwe.ac.uk
    "user"     : "root", //p fet21056806
    "password" : "password",
    "database" : "newSchema" // fet..
}); */


var app = express();
app.set("view engine","ejs");
app.use(express.static("static"));


function serverError(error, response) {
    response.status(500); // 500 Internal Server Error
    response.send(error);
}



/* request query for for the search field on fsa file */
function splash(request, response) {
if (request.query.search){
    connection.query(SEARCH_QUERY, ["%"+request.query.search + "%"], function(err, rows, fields){
        if (err) throw err;
    else response.render("fsa", {results: rows});
    });
}

else connection.query(QUERY, function(err, rows, fields) {
    if (err) throw err;
    else response.render("index",{results: rows});
});
}


app.get("/",splash);

//app.get("/nav2.html",splash);

app.get("/index.html",splash);

//app.get("/head.html",splash);

//app.get("/fsa.html",splash);


// Request user geolocation and callback with lat, lon
function getLocation(fun) {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(loc) {
        fun(loc.coords.latitude, loc.coords.longitude);
        })
    }
    else {
        alert("Geolocation is not supported by this browser.");
        // location defaults to central Bristol
        fun(51.454514, -2.587910);
    }
}

// Load map with lat, lon query string
function loadMap(lat,lon) {
    location.href="map.html?lat="+lat+"&lon="+lon;
}



app.get("/map.html",function(request, response) {
    connection.query(QUERY, function(err, rows, fields) {
        if (err) serverError(err, response);
        else response.render("map", { results: rows, lat: request.query.lat, lon: request.query.lon });
    });
});

app.get("/fsa.html",function(request, response) {
    if (request.query.search){
        connection.query(SEARCH_QUERY, ["%"+request.query.search + "%"], function(err, rows, fields){
            if (err) throw err;
        else response.render("fsa", {results: rows});
        });
    }
    else
    connection.query(FSA_QUERY, function(err, rows, fields) {
        if (err) serverError(err, response);
        else response.render("fsa", { results: rows, lat: request.query.lat, lon: request.query.lon });
    });
});

if (process.env.NODE_ENV!="test"){ //makes server not run if testing 
    app.listen(PORT);
    console.log("Server listening on http://localhost:%s",PORT); 
}


exports.app = app;
exports.serverError = serverError;
exports.connection = connection;