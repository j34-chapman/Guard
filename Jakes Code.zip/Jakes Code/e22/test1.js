import { Selector } from 'testcafe';

fixture `Guard`
    .page `http://localhost:8080/index.html`;

    test('UC3: Search', async function(t) {
        await t
        .click('#Find-safest-area')
        .typeText('#search-box','Southmead')
        .click('#search')
        .expect(Selector('.area').withText(/Southmead/).exists).ok()
    });