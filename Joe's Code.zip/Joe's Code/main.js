// Access from browser with http://localhost:8080/

const express = require('express');
const mysql = require('mysql');
const conf = require('./conf.json');

const QUERY1 = "SELECT * FROM `crime`";
const QUERY2 = "SELECT * FROM `crime` Where TIME = ?";
const QUERY3 = "SELECT * FROM `crime` Where WARDNAME LIKE ?";
const SEARCH_QUERY = "SELECT * FROM `crime` Where WARDNAME LIKE ?";


var app = express();

// configure Express to use embedded JavaScript
app.set("view engine", "ejs");

// serve static content from 'static' folder
app.use(express.static('static'));

// callback function for the splash page request handler
function splash(request, response) {
    // if no type is specified use QUERY1
    if (typeof request.query.type == 'undefined') { 
        connection.query(QUERY1, function (err, rows, fields) {
            if (err) {
                response.status(500);
                response.send(err);
            }
            else {
                response.render("index", { 'rows': rows });
            }
        });        
    }
    else { // QUERY2 selects matching type
        connection.query(QUERY2, [request.query.type], function (err, rows, fields) {
            if (err) {
                response.status(500);
                response.send(err);
            }
            else {
                response.render("index", { 'rows': rows });
            }
        });
    }
}

// Splash page (index.html) is served by default
app.get("/", splash);
app.get("/index.html", splash);


//report pages
app.get("/report.html", function(request, response) {
    response.render("report", request.query);
});
app.get("/report_add.html", function (request, response) {
    connection.query(QUERY1, [request.query.type], function (err, rows, fields) {
        if (err) {
            response.status(500);
            response.send(err);
        }
        else {
            response.render("report_add", { 'rows': rows });
        }
    });
});

app.get("/viewbycategory.html", function (request, response) {
    if (typeof request.query.type == 'undefined') { 
        connection.query(QUERY1, function (err, rows, fields) {
            if (err) {
                response.status(500);
                response.send(err);
            }
            else {
                response.render("viewbycategory", { 'rows': rows });
            }
        });        
    }
});

//view by date
app.get("/viewbydate.html", function (request, response) {
    connection.query(QUERY2, [request.query.type], function (err, rows, fields) {
        if (err) {
            response.status(500);
            response.send(err);
        }
        else {
            response.render("viewbydate", { 'rows': rows });
        }
    });
});

//view by ward
app.get("/viewbyward.html", function (request, response) {
    connection.query(QUERY1, function (err, rows, fields) {
        if (err) {
            response.status(500);
            response.send(err);
        }
        else {
            response.render("viewbyward", { 'rows': rows });
        }
    });
});
//search by location
app.get("/searchbylocation.html", function (request, response) {
    connection.query(QUERY3, ["%"+request.query.search+"%"], function (err, rows, fields) {
        if (err) {
            response.status(500);
            response.send(err);
        }
        else {
            response.render("searchbylocation", { 'rows': rows });
        }
    });
});






//map page
app.get("/map.html", function (request, response) {
    response.render("map", request.query);
});


//search function
app.get("/search.html", function (request, response) {
    connection.query(SEARCH_QUERY, ["%"+request.query.search+"%"], function (err, rows, fields) {
        if (err) {
            response.status(500);
            response.send(err);
        }
        else {
            response.render("search", { 'rows': rows });
        }
    });
});

var connection = mysql.createConnection(conf.db);

connection.connect(function (err) {
    if (err) {
        console.error("Connection error: ", err.message);
    } else {
        console.log("Connected as: ", connection.threadId);
    }
});

app.listen(conf.port);
console.log("Listening on port %s", conf.port);