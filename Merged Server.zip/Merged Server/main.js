// Access from browser with http://localhost:8080/

//joe
const express = require('express');
const mysql = require('mysql');
const conf = require('./conf.json');

//joe
const QUERY1 = "SELECT * FROM `crime`";
const QUERY2 = "SELECT * FROM `crime` Where TIME = ?";
const QUERY3 = "SELECT * FROM `crime` Where WARDNAME LIKE ?";
const SEARCH_QUERY = "SELECT * FROM `crime` Where WARDNAME LIKE ?";

//jake
var QUERY = 'SELECT * FROM `crime`';
TYPE_QUERY = 'SELECT * FROM `crime` WHERE type = ?';// search query
var FSA_QUERY = 'SELECT * FROM `crime` order by ALLCRIMES  ';

var app = express();

// configure Express to use embedded JavaScript
app.set("view engine", "ejs");

// serve static content from 'static' folder
app.use(express.static('static'));


function serverError(error, response) {
    response.status(500); // 500 Internal Server Error
    response.send(error);
}

/* request query for for the search field on fsa file */
function splash(request, response) {
    if (request.query.search){
        connection.query(SEARCH_QUERY, ["%"+request.query.search + "%"], function(err, rows, fields){
            if (err) throw err;
        else response.render("fsa", {results: rows});
        });
    }
    
    else connection.query(QUERY, function(err, rows, fields) {
        if (err) throw err;
        else response.render("index",{results: rows});
    });
}


app.get("/",splash);    
app.get("/index.html",splash);

//find safest area
app.get("/fsa.html",function(request, response) {
    if (request.query.search){
        connection.query(SEARCH_QUERY, ["%"+request.query.search + "%"], function(err, rows, fields){
            if (err) throw err;
        else response.render("fsa", {results: rows});
        });
    }
    else
    connection.query(FSA_QUERY, function(err, rows, fields) {
        if (err) serverError(err, response);
        else response.render("fsa", { results: rows, lat: request.query.lat, lon: request.query.lon });
    });
});

//map 
app.get("/map.html",function(request, response) {
    connection.query(QUERY, function(err, rows, fields) {
        if (err) serverError(err, response);
        else response.render("map", { results: rows, lat: request.query.lat, lon: request.query.lon });
    });
});
// Request user geolocation and callback with lat, lon
function getLocation(fun) {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(function(loc) {
        fun(loc.coords.latitude, loc.coords.longitude);
        })
    }
    else {
        alert("Geolocation is not supported by this browser.");
        // location defaults to central Bristol
        fun(51.454514, -2.587910);
    }
}


//view crime by category
app.get("/viewbycategory.html", function (request, response) {
    if (typeof request.query.type == 'undefined') { 
        connection.query(QUERY1, function (err, rows, fields) {
            if (err) {
                response.status(500);
                response.send(err);
            }
            else {
                response.render("viewbycategory", { results: rows });
            }
        });        
    }
});
//view by date
app.get("/viewbydate.html", function (request, response) {
    connection.query(QUERY2, [request.query.type], function (err, rows, fields) {
        if (err) {
            response.status(500);
            response.send(err);
        }
        else {
            response.render("viewbydate", { results : rows });
        }
    });
});
//view by ward
app.get("/viewbyward.html", function (request, response) {
    connection.query(QUERY1, function (err, rows, fields) {
        if (err) {
            response.status(500);
            response.send(err);
        }
        else {
            response.render("viewbyward", { results: rows });
        }
    });
});
//search by location
app.get("/searchbylocation.html", function (request, response) {
    connection.query(QUERY3, ["%"+request.query.search+"%"], function (err, rows, fields) {
        if (err) {
            response.status(500);
            response.send(err);
        }
        else {
            response.render("searchbylocation", { results: rows });
        }
    });
});
//#end of view by category pages

//database connection
var connection = mysql.createConnection(conf.db);

connection.connect(function (err) {
    if (err) {
        console.error("Connection error: ", err.message);
    } else {
        console.log("Connected as: ", connection.threadId);
    }
});

app.listen(conf.port);
console.log("Listening on port %s", conf.port);